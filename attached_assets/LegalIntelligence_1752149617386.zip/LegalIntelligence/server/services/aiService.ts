import { openaiService } from "./openaiService";
import { openrouterService } from "./openrouterService";

export interface AIResponse {
  content: string;
  model: string;
  tokensUsed?: number;
}

class AIService {
  async generateResponse(prompt: string, plan: "free" | "premium" | "enterprise"): Promise<AIResponse> {
    try {
      // Use different models based on plan
      if (plan === "premium" || plan === "enterprise") {
        return await openaiService.generateResponse(prompt);
      } else {
        return await openrouterService.generateResponse(prompt);
      }
    } catch (error) {
      console.error("AI Service Error:", error);
      throw new Error("Failed to generate AI response");
    }
  }

  async analyzeDocument(documentText: string, plan: "free" | "premium" | "enterprise"): Promise<AIResponse> {
    if (plan === "free") {
      throw new Error("Document analysis requires Premium subscription");
    }

    const analysisPrompt = `
You are a legal expert AI assistant. Analyze the following legal document and provide:

1. A brief summary
2. Key points and clauses
3. Potential risks or concerns
4. Recommendations for the reader

Document:
${documentText}

Please provide a comprehensive legal analysis in a clear, structured format.
`;

    try {
      if (plan === "premium" || plan === "enterprise") {
        return await openaiService.generateResponse(analysisPrompt);
      } else {
        return await openrouterService.generateResponse(analysisPrompt);
      }
    } catch (error) {
      console.error("Document Analysis Error:", error);
      throw new Error("Failed to analyze document");
    }
  }

  formatLegalResponse(content: string): string {
    // Add legal formatting and structure
    const legalPrefixes = [
      "**Legal Analysis:**",
      "**Your Rights:**", 
      "**Recommended Action:**",
      "**Important Notice:**"
    ];

    // Add appropriate legal disclaimers
    const disclaimer = "\n\n*Disclaimer: This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.*";

    return content + disclaimer;
  }
}

export const aiService = new AIService();
