import type { AIResponse } from "./aiService";

class OpenRouterService {
  private apiKey: string;
  private baseUrl: string = "https://openrouter.ai/api/v1";

  constructor() {
    this.apiKey = process.env.OPENROUTER_API_KEY || "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";
  }

  async generateResponse(prompt: string): Promise<AIResponse> {
    try {
      const legalSystemPrompt = `You are LexAI, a legal assistant that helps people understand their rights and protect themselves from intimidation. You provide clear, practical legal guidance while emphasizing user empowerment.

Guidelines:
- Explain legal concepts in simple terms
- Distinguish between legal requirements vs. intimidation tactics
- Structure responses with clear sections like "Analysis:", "Your Rights:", "Recommended Action:"
- Build user confidence while being legally accurate
- Suggest when professional legal help is needed

Remember: You're using Mistral Small AI (Free Plan). For advanced analysis, users can upgrade to LexAI Elite with GPT-4o.`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": process.env.REPLIT_DOMAINS?.split(',')[0] || "http://localhost:5000",
        },
        body: JSON.stringify({
          model: "mistralai/mistral-small-24b-instruct-2501:free",
          messages: [
            { role: "system", content: legalSystemPrompt },
            { role: "user", content: prompt }
          ],
          temperature: 0.7,
          max_tokens: 800,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenRouter API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;

      if (!content) {
        throw new Error("No response content received from OpenRouter");
      }

      return {
        content: this.formatLegalResponse(content),
        model: "mistral-small",
        tokensUsed: data.usage?.total_tokens,
      };
    } catch (error) {
      console.error("OpenRouter Service Error:", error);
      
      // Fallback response for free users
      const fallbackResponse = this.getFallbackResponse(prompt);
      return {
        content: fallbackResponse,
        model: "fallback",
      };
    }
  }

  private formatLegalResponse(content: string): string {
    // Add free plan indicator and upgrade suggestion
    let formatted = content;

    // Add upgrade notice for free users
    if (!formatted.includes("upgrade")) {
      formatted += "\n\n💡 **Want deeper legal analysis?** Upgrade to LexAI Elite for GPT-4o powered insights, document analysis, and premium legal intelligence.";
    }

    // Add legal disclaimer
    if (!formatted.includes("Disclaimer:")) {
      formatted += "\n\n**Disclaimer:** This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.";
    }

    return formatted;
  }

  private getFallbackResponse(prompt: string): string {
    // Basic fallback responses for common legal scenarios
    if (prompt.toLowerCase().includes("prosecutor") || prompt.toLowerCase().includes("police")) {
      return `**Analysis:** When contacted by law enforcement, it's important to understand your rights and obligations.

**Your Rights:**
• You have the right to remain silent
• You have the right to an attorney
• You are not required to answer questions without proper legal representation
• Verbal threats without proper documentation may be intimidation tactics

**Recommended Action:**
• Request all communications in writing
• Ask for specific legal citations and documentation
• Do not feel pressured to comply with verbal demands
• Consider consulting with a legal professional

**Important:** Only comply with properly documented legal summons or court orders. Verbal threats should be treated with caution.

💡 **Want deeper legal analysis?** Upgrade to LexAI Elite for GPT-4o powered insights and premium legal intelligence.

**Disclaimer:** This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.`;
    }

    if (prompt.toLowerCase().includes("contract") || prompt.toLowerCase().includes("agreement")) {
      return `**Analysis:** Contract review requires careful examination of terms and obligations.

**Key Areas to Review:**
• Payment terms and conditions
• Termination clauses
• Liability limitations
• Dispute resolution procedures

**Your Rights:**
• You have the right to understand all terms before signing
• You can negotiate unfavorable terms
• You can seek legal counsel for complex agreements

**Recommended Action:**
• Read all terms carefully
• Question anything unclear
• Consider legal review for significant contracts
• Keep copies of all signed documents

💡 **Want detailed contract analysis?** Upgrade to LexAI Elite for document analysis and advanced legal review.

**Disclaimer:** This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.`;
    }

    // Generic legal guidance fallback
    return `**Analysis:** Legal matters require careful consideration of your specific situation and applicable laws.

**General Guidance:**
• Understand your rights before taking action
• Document all communications
• Be wary of pressure tactics or urgent demands
• Seek clarification on legal obligations

**Your Rights:**
• Right to understand legal processes affecting you
• Right to legal representation
• Right to request written documentation
• Protection against intimidation tactics

**Recommended Action:**
• Gather all relevant documentation
• Research applicable laws or regulations
• Consider consulting with a qualified attorney
• Do not act under pressure without understanding consequences

💡 **Want personalized legal analysis?** Upgrade to LexAI Elite for GPT-4o powered insights tailored to your specific situation.

**Disclaimer:** This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.`;
  }
}

export const openrouterService = new OpenRouterService();
