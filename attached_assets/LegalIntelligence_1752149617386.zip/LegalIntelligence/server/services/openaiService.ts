import OpenAI from "openai";
import type { AIResponse } from "./aiService";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "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"
});

class OpenAIService {
  async generateResponse(prompt: string): Promise<AIResponse> {
    try {
      const legalSystemPrompt = `You are LexAI, an elite legal intelligence assistant designed to protect people from government intimidation and legal uncertainty. Your mission is to:

1. Provide clear, accurate legal guidance that empowers users
2. Detect and warn against intimidation tactics or false authority
3. Explain complex legal concepts in simple, understandable terms
4. Always prioritize the user's legal rights and protection
5. Distinguish between legal obligations vs. optional compliance

IMPORTANT GUIDELINES:
- Always start responses with clear analysis sections
- Use formatting like **Analysis:**, **Your Rights:**, **Recommended Action:**
- Be authoritative but explain the reasoning
- Warn users about potential intimidation tactics
- Suggest when to seek additional legal counsel
- Never provide advice that could harm the user

Respond in a professional, confident tone that builds user confidence while being legally accurate.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: legalSystemPrompt },
          { role: "user", content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error("No response content received from OpenAI");
      }

      return {
        content: this.formatLegalResponse(content),
        model: "gpt-4o",
        tokensUsed: response.usage?.total_tokens,
      };
    } catch (error) {
      console.error("OpenAI Service Error:", error);
      throw new Error(`OpenAI API error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async analyzeDocument(documentText: string): Promise<AIResponse> {
    try {
      const analysisPrompt = `You are LexAI's document analysis expert. Analyze this legal document and provide a structured analysis that helps the user understand their rights and obligations.

Document to analyze:
${documentText}

Please provide a JSON response with the following structure:
{
  "summary": "Brief overview of the document",
  "document_type": "Type of legal document",
  "key_points": ["List of important clauses and terms"],
  "risks": ["Potential risks or unfavorable terms"],
  "recommendations": ["Specific actions the user should take"],
  "legal_obligations": ["What the user MUST do legally"],
  "optional_items": ["What the user CAN do but is not required to"],
  "red_flags": ["Warning signs of intimidation or unfair terms"]
}`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "user", content: analysisPrompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
        max_tokens: 1500,
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error("No response content received from OpenAI");
      }

      return {
        content: this.formatDocumentAnalysis(content),
        model: "gpt-4o",
        tokensUsed: response.usage?.total_tokens,
      };
    } catch (error) {
      console.error("OpenAI Document Analysis Error:", error);
      throw new Error(`Document analysis failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private formatLegalResponse(content: string): string {
    // Ensure proper legal formatting
    let formatted = content;

    // Add legal disclaimer if not present
    if (!formatted.includes("Disclaimer:")) {
      formatted += "\n\n**Disclaimer:** This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.";
    }

    return formatted;
  }

  private formatDocumentAnalysis(jsonContent: string): string {
    try {
      const analysis = JSON.parse(jsonContent);
      
      let formatted = `**Document Analysis Complete**\n\n`;
      
      if (analysis.summary) {
        formatted += `**Summary:**\n${analysis.summary}\n\n`;
      }
      
      if (analysis.document_type) {
        formatted += `**Document Type:** ${analysis.document_type}\n\n`;
      }
      
      if (analysis.key_points && analysis.key_points.length > 0) {
        formatted += `**Key Points:**\n`;
        analysis.key_points.forEach((point: string) => {
          formatted += `• ${point}\n`;
        });
        formatted += '\n';
      }
      
      if (analysis.legal_obligations && analysis.legal_obligations.length > 0) {
        formatted += `**Legal Obligations (What you MUST do):**\n`;
        analysis.legal_obligations.forEach((obligation: string) => {
          formatted += `• ${obligation}\n`;
        });
        formatted += '\n';
      }
      
      if (analysis.risks && analysis.risks.length > 0) {
        formatted += `**⚠️ Potential Risks:**\n`;
        analysis.risks.forEach((risk: string) => {
          formatted += `• ${risk}\n`;
        });
        formatted += '\n';
      }
      
      if (analysis.red_flags && analysis.red_flags.length > 0) {
        formatted += `**🚨 Red Flags:**\n`;
        analysis.red_flags.forEach((flag: string) => {
          formatted += `• ${flag}\n`;
        });
        formatted += '\n';
      }
      
      if (analysis.recommendations && analysis.recommendations.length > 0) {
        formatted += `**Recommendations:**\n`;
        analysis.recommendations.forEach((rec: string) => {
          formatted += `• ${rec}\n`;
        });
        formatted += '\n';
      }
      
      formatted += `**Disclaimer:** This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.`;
      
      return formatted;
    } catch (error) {
      // If JSON parsing fails, return the raw content
      return jsonContent + "\n\n**Disclaimer:** This analysis is for informational purposes only and does not constitute legal advice. Consult with a qualified attorney for specific legal matters.";
    }
  }
}

export const openaiService = new OpenAIService();
