import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiService } from "./services/aiService";
import { insertMessageSchema, insertConversationSchema } from "@shared/schema";
import { z } from "zod";

// Mock session for demo purposes
interface MockSession {
  userId: number;
}

// Mock user ID for demo
const DEMO_USER_ID = 1;

async function ensureUser() {
  let user = await storage.getUser(DEMO_USER_ID);
  if (!user) {
    user = await storage.createUser({
      email: "demo@lexai.com",
      plan: "free",
    });
  }
  return user;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Ensure demo user exists
  await ensureUser();

  // Get usage information
  app.get("/api/usage", async (req, res) => {
    try {
      const user = await storage.getUser(DEMO_USER_ID);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const maxQuestions = user.plan === "free" ? 50 : user.plan === "premium" ? 150 : Infinity;
      
      // Check if usage should be reset
      if (user.usageResetDate && new Date() > user.usageResetDate) {
        await storage.resetUsage(user.id);
        user.usageCount = 0;
      }

      res.json({
        used: user.usageCount,
        total: maxQuestions,
        plan: user.plan,
        resetDate: user.usageResetDate,
      });
    } catch (error) {
      console.error("Error fetching usage:", error);
      res.status(500).json({ message: "Failed to fetch usage" });
    }
  });

  // Increment usage
  app.post("/api/usage/increment", async (req, res) => {
    try {
      await storage.incrementUsage(DEMO_USER_ID);
      res.json({ success: true });
    } catch (error) {
      console.error("Error incrementing usage:", error);
      res.status(500).json({ message: "Failed to increment usage" });
    }
  });

  // Get conversations
  app.get("/api/conversations", async (req, res) => {
    try {
      const conversations = await storage.getConversations(DEMO_USER_ID);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  // Send chat message
  app.post("/api/chat/message", async (req, res) => {
    try {
      const { content } = req.body;
      
      if (!content?.trim()) {
        return res.status(400).json({ message: "Message content is required" });
      }

      const user = await storage.getUser(DEMO_USER_ID);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check usage limits
      const maxQuestions = user.plan === "free" ? 50 : user.plan === "premium" ? 150 : Infinity;
      if (user.usageCount >= maxQuestions) {
        return res.status(429).json({ 
          message: "Usage limit reached. Upgrade your plan or wait for the next cycle." 
        });
      }

      // Create or get conversation
      let conversations = await storage.getConversations(DEMO_USER_ID);
      let conversation;
      
      if (conversations.length === 0) {
        conversation = await storage.createConversation({
          userId: DEMO_USER_ID,
          title: content.slice(0, 50) + (content.length > 50 ? "..." : ""),
        });
      } else {
        conversation = conversations[0];
      }

      // Save user message
      await storage.createMessage({
        conversationId: conversation.id,
        content,
        role: "user",
      });

      // Get AI response
      const aiResponse = await aiService.generateResponse(content, user.plan);

      // Save AI response
      const assistantMessage = await storage.createMessage({
        conversationId: conversation.id,
        content: aiResponse.content,
        role: "assistant",
        model: aiResponse.model,
        tokensUsed: aiResponse.tokensUsed,
        verified: true,
      });

      // Increment usage
      await storage.incrementUsage(DEMO_USER_ID);

      res.json({
        id: assistantMessage.id,
        content: assistantMessage.content,
        model: assistantMessage.model,
        verified: assistantMessage.verified,
      });
    } catch (error) {
      console.error("Error processing chat message:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  // Analyze document
  app.post("/api/analyze-document", async (req, res) => {
    try {
      const user = await storage.getUser(DEMO_USER_ID);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.plan === "free") {
        return res.status(403).json({ 
          message: "Document analysis requires Premium subscription" 
        });
      }

      // Mock document analysis for now
      const analysis = {
        summary: "This document appears to be a standard contract with several important clauses that require attention.",
        keyPoints: [
          "Payment terms are clearly defined",
          "Termination clause allows for 30-day notice",
          "Intellectual property rights are assigned to the company"
        ],
        risks: [
          "Non-compete clause may be overly restrictive",
          "Liability limitations heavily favor the other party",
          "Arbitration clause requires specific jurisdiction"
        ],
        recommendations: [
          "Review non-compete terms with legal counsel",
          "Negotiate more balanced liability terms",
          "Consider alternative dispute resolution options"
        ]
      };

      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing document:", error);
      res.status(500).json({ message: "Failed to analyze document" });
    }
  });

  // Get dashboard data
  app.get("/api/dashboard", async (req, res) => {
    try {
      const user = await storage.getUser(DEMO_USER_ID);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const conversations = await storage.getConversations(DEMO_USER_ID);
      const documents = await storage.getDocuments(DEMO_USER_ID);
      
      // Calculate total questions from all conversations
      let totalQuestions = 0;
      for (const conv of conversations) {
        const messages = await storage.getMessages(conv.id);
        totalQuestions += messages.filter(m => m.role === "user").length;
      }

      const maxQuestions = user.plan === "free" ? 50 : user.plan === "premium" ? 150 : Infinity;

      // Mock recent activity
      const recentActivity = conversations.slice(0, 5).map(conv => ({
        id: conv.id.toString(),
        type: "chat" as const,
        title: conv.title || "Legal Consultation",
        timestamp: conv.updatedAt,
      }));

      res.json({
        totalQuestions,
        documentsAnalyzed: documents.length,
        monthlyUsage: {
          used: user.usageCount,
          total: maxQuestions,
          plan: user.plan,
        },
        recentActivity,
      });
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
