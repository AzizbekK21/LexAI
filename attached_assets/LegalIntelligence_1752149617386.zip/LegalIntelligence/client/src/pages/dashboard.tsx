import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Navigation } from "@/components/layout/navigation";
import { UsageProgress } from "@/components/ui/usage-progress";
import { AnimatedLogo } from "@/components/ui/animated-logo";
import { 
  MessageSquare, 
  FileText, 
  Crown, 
  TrendingUp, 
  Shield, 
  Calendar,
  Clock,
  CheckCircle
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

interface DashboardStats {
  totalQuestions: number;
  documentsAnalyzed: number;
  monthlyUsage: {
    used: number;
    total: number;
    plan: "free" | "premium";
  };
  recentActivity: Array<{
    id: string;
    type: "chat" | "document";
    title: string;
    timestamp: Date;
  }>;
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch dashboard data");
      return response.json();
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-16 flex items-center justify-center min-h-[50vh]">
          <AnimatedLogo size="lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-16">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">
              Welcome to your <span className="text-gradient">Legal Dashboard</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Monitor your legal AI usage and access powerful features
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Stats */}
            <div className="lg:col-span-2 space-y-6">
              {/* Usage Overview */}
              <Card className="glass-morphism">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    <span>Monthly Usage</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {stats?.monthlyUsage && (
                    <UsageProgress
                      used={stats.monthlyUsage.used}
                      total={stats.monthlyUsage.total}
                      plan={stats.monthlyUsage.plan}
                    />
                  )}
                </CardContent>
              </Card>

              {/* Stats Cards */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="glass-morphism hover-lift">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 premium-gradient rounded-xl flex items-center justify-center">
                        <MessageSquare className="w-6 h-6 text-primary-foreground" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Total Questions</p>
                        <p className="text-3xl font-bold">{stats?.totalQuestions || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-morphism hover-lift">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 premium-gradient rounded-xl flex items-center justify-center">
                        <FileText className="w-6 h-6 text-primary-foreground" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Documents Analyzed</p>
                        <p className="text-3xl font-bold">{stats?.documentsAnalyzed || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card className="glass-morphism">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-primary" />
                    <span>Recent Activity</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {stats?.recentActivity?.length ? (
                      stats.recentActivity.map((activity) => (
                        <div key={activity.id} className="flex items-center space-x-4 p-3 bg-secondary rounded-lg">
                          <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                            {activity.type === "chat" ? (
                              <MessageSquare className="w-4 h-4 text-primary" />
                            ) : (
                              <FileText className="w-4 h-4 text-primary" />
                            )}
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{activity.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(activity.timestamp).toLocaleDateString()}
                            </p>
                          </div>
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>No activity yet. Start a conversation to see your history here.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <Card className="glass-morphism">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link href="/chat">
                    <Button className="w-full justify-start" variant="secondary">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      New Legal Question
                    </Button>
                  </Link>
                  <Link href="/chat?tab=documents">
                    <Button className="w-full justify-start" variant="secondary">
                      <FileText className="w-4 h-4 mr-2" />
                      Analyze Document
                    </Button>
                  </Link>
                  <Button className="w-full justify-start" variant="secondary">
                    <Calendar className="w-4 h-4 mr-2" />
                    Schedule Consultation
                  </Button>
                </CardContent>
              </Card>

              {/* Plan Status */}
              <Card className="glass-morphism">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="w-5 h-5" />
                    <span>Protection Level</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {stats?.monthlyUsage?.plan === "premium" ? (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Crown className="w-5 h-5 text-primary" />
                        <span className="font-semibold text-primary">Elite Protection</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        You have access to GPT-4o, document analysis, and all premium features.
                      </p>
                      <Button variant="outline" size="sm" className="w-full">
                        Manage Subscription
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Shield className="w-5 h-5 text-muted-foreground" />
                        <span className="font-semibold">Free Shield</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Upgrade to Elite Protection for unlimited power and advanced features.
                      </p>
                      <Button className="w-full premium-gradient text-primary-foreground">
                        <Crown className="w-4 h-4 mr-2" />
                        Upgrade to Elite
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Legal Tip */}
              <Card className="glass-morphism border-primary/50">
                <CardHeader>
                  <CardTitle className="text-primary">💡 Legal Tip</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Always request written documentation when dealing with government officials. 
                    Verbal threats without proper legal backing are often intimidation tactics.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
