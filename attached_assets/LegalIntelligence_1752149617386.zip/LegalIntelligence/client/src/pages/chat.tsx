import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navigation } from "@/components/layout/navigation";
import { ChatInterface } from "@/components/ui/chat-interface";
import { DocumentAnalyzer } from "@/components/ui/document-analyzer";
import { UsageProgress } from "@/components/ui/usage-progress";
import { AnimatedLogo } from "@/components/ui/animated-logo";
import { MessageSquare, FileText, Crown, Settings, History } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
  plan?: "free" | "premium";
  verified?: boolean;
}

interface UsageData {
  used: number;
  total: number;
  plan: "free" | "premium";
}

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeTab, setActiveTab] = useState("chat");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch usage data
  const { data: usage } = useQuery<UsageData>({
    queryKey: ["/api/usage"],
    queryFn: async () => {
      const response = await fetch("/api/usage", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch usage");
      return response.json();
    }
  });

  // Fetch conversations
  const { data: conversations } = useQuery({
    queryKey: ["/api/conversations"],
    queryFn: async () => {
      const response = await fetch("/api/conversations", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch conversations");
      return response.json();
    }
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/chat/message", { content });
      return response.json();
    },
    onSuccess: (data) => {
      const assistantMessage: Message = {
        id: data.id || Date.now().toString(),
        content: data.content,
        role: "assistant",
        timestamp: new Date(),
        plan: usage?.plan || "free",
        verified: true,
      };
      setMessages(prev => [...prev, assistantMessage]);
      queryClient.invalidateQueries({ queryKey: ["/api/usage"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message",
        variant: "destructive",
      });
    },
  });

  // Document analysis mutation
  const analyzeDocumentMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("document", file);
      const response = await fetch("/api/analyze-document", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to analyze document");
      return response.text();
    },
    onSuccess: (analysis) => {
      toast({
        title: "Analysis Complete",
        description: "Your document has been analyzed successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Failed to analyze document",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = async (content: string) => {
    if (usage && usage.used >= usage.total) {
      toast({
        title: "Usage Limit Reached",
        description: "You've reached your monthly limit. Upgrade or wait for the new cycle.",
        variant: "destructive",
      });
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    
    sendMessageMutation.mutate(content);
  };

  const handleAnalyzeDocument = async (file: File): Promise<string> => {
    if (usage?.plan === "free") {
      throw new Error("Document analysis requires Premium subscription");
    }
    
    return new Promise((resolve, reject) => {
      analyzeDocumentMutation.mutate(file, {
        onSuccess: resolve,
        onError: reject,
      });
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-4 gap-6">
            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
              {/* Usage Card */}
              <Card className="glass-morphism">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <AnimatedLogo variant="icon" size="sm" />
                    <span>LexAI Status</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {usage && (
                    <UsageProgress
                      used={usage.used}
                      total={usage.total}
                      plan={usage.plan}
                    />
                  )}
                  
                  {usage?.plan === "free" && (
                    <div className="mt-4 p-3 bg-secondary rounded-lg">
                      <p className="text-sm text-muted-foreground mb-2">
                        You're using Mistral Small AI (Free Plan)
                      </p>
                      <Button size="sm" className="premium-gradient text-primary-foreground w-full">
                        <Crown className="w-4 h-4 mr-2" />
                        Upgrade to Elite
                      </Button>
                    </div>
                  )}
                  
                  {usage?.plan === "premium" && (
                    <div className="mt-4 p-3 bg-primary/10 rounded-lg">
                      <div className="flex items-center space-x-2 mb-1">
                        <Crown className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium text-primary">Elite Protection Active</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Using GPT-4o for maximum legal power
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Recent Conversations */}
              <Card className="glass-morphism">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <History className="w-5 h-5" />
                    <span>Recent</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {conversations?.slice(0, 5).map((conv: any) => (
                      <Button
                        key={conv.id}
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start text-left h-auto p-2"
                      >
                        <div className="truncate">
                          <div className="text-sm font-medium truncate">
                            {conv.title || "Untitled Conversation"}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(conv.timestamp).toLocaleDateString()}
                          </div>
                        </div>
                      </Button>
                    )) || (
                      <p className="text-sm text-muted-foreground">No conversations yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="chat" className="flex items-center space-x-2">
                    <MessageSquare className="w-4 h-4" />
                    <span>Legal Chat</span>
                  </TabsTrigger>
                  <TabsTrigger value="documents" className="flex items-center space-x-2">
                    <FileText className="w-4 h-4" />
                    <span>Document Analysis</span>
                    {usage?.plan === "premium" && (
                      <Badge variant="default" className="text-xs ml-1">Premium</Badge>
                    )}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="chat" className="space-y-6">
                  <ChatInterface
                    messages={messages}
                    onSendMessage={handleSendMessage}
                    isLoading={sendMessageMutation.isPending}
                    plan={usage?.plan || "free"}
                    className="h-[600px]"
                  />
                </TabsContent>

                <TabsContent value="documents" className="space-y-6">
                  <DocumentAnalyzer
                    onAnalyze={handleAnalyzeDocument}
                    plan={usage?.plan || "free"}
                  />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
