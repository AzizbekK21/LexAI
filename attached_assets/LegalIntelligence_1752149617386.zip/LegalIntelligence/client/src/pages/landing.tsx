import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Navigation } from "@/components/layout/navigation";
import { Footer } from "@/components/layout/footer";
import { AnimatedLogo } from "@/components/ui/animated-logo";
import { PricingCard } from "@/components/ui/pricing-card";
import { ChatInterface } from "@/components/ui/chat-interface";
import { 
  Brain, 
  FileText, 
  Shield, 
  Briefcase, 
  Globe, 
  History,
  Crown,
  Play,
  CheckCircle,
  Clock,
  Users,
  Calendar,
  Lock,
  FolderSync,
  Star
} from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  // Mock chat data for demo
  const demoMessages = [
    {
      id: "1",
      content: "A prosecutor called me saying I violated Article 156 and must come to their office or face jail time. What should I do?",
      role: "user" as const,
      timestamp: new Date(),
    },
    {
      id: "2",
      content: "**Analysis:** Article 156 is typically a warning statute, not a criminal offense requiring immediate compliance.\n\n**Your Rights:** You are not legally obligated to attend unless officially summoned with proper documentation.\n\n**Recommended Action:** Request written summons with case details. If prosecutor persists with verbal threats, they may be using intimidation tactics. Document all communications.",
      role: "assistant" as const,
      timestamp: new Date(),
      plan: "premium" as const,
      verified: true,
    },
  ];

  const features = [
    {
      icon: Brain,
      title: "Instant Legal Analysis",
      description: "Get immediate analysis of any legal situation. From prosecutor calls to business regulations - understand your rights instantly.",
    },
    {
      icon: FileText,
      title: "Document Intelligence",
      description: "Upload contracts, legal documents, or government letters. Our AI analyzes everything and explains in simple terms.",
    },
    {
      icon: Shield,
      title: "Protection Shield",
      description: "Detect intimidation tactics and false authority. Get clear guidance on what you must do vs. what you can ignore.",
    },
    {
      icon: Briefcase,
      title: "Business Legal Guide",
      description: "Calculate customs costs, understand regulations, plan legally compliant business strategies with confidence.",
    },
    {
      icon: Globe,
      title: "Global Legal Database",
      description: "Access real-time legal information from multiple jurisdictions. Multilingual support for global protection.",
    },
    {
      icon: History,
      title: "Memory & History",
      description: "Your AI remembers past conversations and builds context over time for increasingly personalized legal guidance.",
    },
  ];

  const pricingPlans = [
    {
      title: "Free Shield",
      description: "Basic legal protection for everyone",
      price: "$0",
      period: "per month",
      plan: "free" as const,
      features: [
        { name: "50 AI questions/month", included: true },
        { name: "Mistral AI (Free Model)", included: true },
        { name: "Basic legal guidance", included: true },
        { name: "Chat history", included: true },
        { name: "Document analysis", included: false },
      ],
      usage: { used: 23, total: 50 },
      currentPlan: true,
    },
    {
      title: "Elite Protection",
      description: "Professional legal intelligence",
      price: "$50",
      period: "per month",
      plan: "premium" as const,
      popular: true,
      features: [
        { name: "150 AI questions/month", included: true },
        { name: "GPT-4o (Premium Model)", included: true },
        { name: "Advanced legal analysis", included: true },
        { name: "PDF document analysis", included: true },
        { name: "Contract review", included: true },
        { name: "No advertisements", included: true },
        { name: "Priority support", included: true },
      ],
    },
    {
      title: "Enterprise",
      description: "For legal professionals & businesses",
      price: "Custom",
      period: "contact sales",
      plan: "enterprise" as const,
      features: [
        { name: "Unlimited questions", included: true },
        { name: "Custom AI models", included: true },
        { name: "Bulk document processing", included: true },
        { name: "API access", included: true },
        { name: "White-label options", included: true },
        { name: "Dedicated support", included: true },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden gradient-animated">
        {/* Background Effects */}
        <div className="absolute inset-0 opacity-15">
          <div className="absolute top-20 left-20 w-96 h-96 gradient-animated rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 btn-premium rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }}></div>
          <div className="absolute top-1/2 left-1/2 w-64 h-64 premium-gradient rounded-full blur-2xl animate-pulse-glow" style={{ animationDelay: "1s" }}></div>
        </div>
        
        <div className="container mx-auto px-6 py-20 relative z-10">
          <div className="text-center animate-fade-in-up">
            <div className="max-w-6xl mx-auto">
              <AnimatedLogo size="xl" className="mx-auto mb-8 animate-float" />
              <h1 className="text-7xl md:text-9xl font-black mb-8 leading-tight text-display">
                Elite Legal <span className="text-gradient-animated">Intelligence</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-4xl mx-auto font-light leading-relaxed">
                Protect yourself from government intimidation. Get instant, accurate legal guidance powered by advanced AI. Never fear the law again.
              </p>
              
              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
                <Link href="/chat">
                  <Button size="lg" className="premium-gradient text-primary-foreground font-bold hover:scale-105 transition-transform duration-300 animate-glow">
                    Start Free Trial
                  </Button>
                </Link>
                <Button variant="secondary" size="lg" className="glass-morphism border-primary/30 hover-lift">
                  <Play className="w-5 h-5 mr-2" />
                  Watch Demo
                </Button>
              </div>
              
              {/* Trust Indicators */}
              <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-muted-foreground">
                <div className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-primary" />
                  <span>Bank-Level Security</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-primary" />
                  <span>24/7 Available</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-primary" />
                  <span>10M+ Protected</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-secondary relative">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-5xl font-bold mb-6 text-gradient">Revolutionary Features</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Advanced AI technology meets luxury design to deliver unparalleled legal protection and intelligence.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card 
                key={index}
                className="glass-morphism feature-card animate-scale-in"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <CardContent className="p-8">
                  <div className="w-16 h-16 premium-gradient rounded-2xl flex items-center justify-center mb-6 animate-float" style={{ animationDelay: `${index * 0.5}s` }}>
                    <feature.icon className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-foreground">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section id="demo" className="py-20 bg-background relative">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-gradient">See LexAI in Action</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Experience the power of elite legal intelligence through our interactive demo.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="animate-scale-in">
              <ChatInterface
                messages={demoMessages}
                onSendMessage={() => {}}
                plan="premium"
                className="h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-secondary relative">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-gradient">Choose Your Protection Level</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              From basic legal guidance to enterprise-level protection, we have the perfect plan for your needs.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <PricingCard
                key={index}
                {...plan}
                className="animate-scale-in"
                style={{ animationDelay: `${index * 0.2}s` }}
                onUpgrade={() => {
                  // Handle upgrade logic
                }}
              />
            ))}
          </div>
          
          {/* Additional Purchase Options */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground mb-4">Need more questions? Purchase additional limits:</p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Button variant="secondary" className="glass-morphism border-primary/30 hover-lift">
                +50 Questions - $10
              </Button>
              <Button variant="secondary" className="glass-morphism border-primary/30 hover-lift">
                +100 Questions - $18
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-background relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full premium-gradient" style={{ clipPath: "polygon(0 0, 100% 0, 0 100%)" }}></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center max-w-4xl mx-auto animate-slide-up">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Stop Fearing the Law.<br />
              <span className="text-gradient">Start Protecting Yourself.</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Join millions who have gained legal confidence and protection through LexAI's revolutionary platform.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
              <Link href="/chat">
                <Button size="lg" className="premium-gradient text-primary-foreground font-bold hover:scale-105 transition-transform duration-300 animate-glow">
                  <Shield className="w-5 h-5 mr-2" />
                  Get Protected Now
                </Button>
              </Link>
              <Button variant="secondary" size="lg" className="glass-morphism border-primary/30 hover-lift">
                <Calendar className="w-5 h-5 mr-2" />
                Schedule Demo
              </Button>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Lock className="w-5 h-5 text-primary" />
                <span>No Credit Card Required</span>
              </div>
              <div className="flex items-center space-x-2">
                <FolderSync className="w-5 h-5 text-primary" />
                <span>Cancel Anytime</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="w-5 h-5 text-primary" />
                <span>4.9/5 Rating</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
