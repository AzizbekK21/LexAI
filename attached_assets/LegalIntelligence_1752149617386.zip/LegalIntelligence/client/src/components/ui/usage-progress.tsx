import React from "react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface UsageProgressProps {
  used: number;
  total: number;
  plan: "free" | "premium" | "enterprise";
  className?: string;
}

export function UsageProgress({ used, total, plan, className }: UsageProgressProps) {
  const percentage = (used / total) * 100;
  const isNearLimit = percentage >= 80;
  const isAtLimit = percentage >= 100;

  const planColors = {
    free: "text-muted-foreground",
    premium: "text-primary",
    enterprise: "text-purple-400"
  };

  const planLabels = {
    free: "Free Plan",
    premium: "Elite Protection",
    enterprise: "Enterprise"
  };

  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Badge variant={plan === "premium" ? "default" : "secondary"} className="text-xs">
            {planLabels[plan]}
          </Badge>
          {isAtLimit && (
            <Badge variant="destructive" className="text-xs">
              Limit Reached
            </Badge>
          )}
        </div>
        <span className={cn("text-sm font-medium", planColors[plan])}>
          {used}/{total} questions
        </span>
      </div>
      
      <div className="relative">
        <Progress 
          value={Math.min(percentage, 100)} 
          className="h-2"
        />
        <div 
          className={cn(
            "absolute top-0 left-0 h-2 rounded-full transition-all duration-500",
            isAtLimit ? "bg-destructive" : isNearLimit ? "bg-yellow-500" : "usage-bar"
          )}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
      </div>
      
      {isNearLimit && !isAtLimit && (
        <p className="text-xs text-yellow-600 dark:text-yellow-400">
          You're approaching your monthly limit
        </p>
      )}
      
      {isAtLimit && (
        <p className="text-xs text-destructive">
          You've reached your monthly limit. Upgrade or wait for the new cycle.
        </p>
      )}
    </div>
  );
}
