import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X, Crown, Zap, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import { UsageProgress } from "./usage-progress";

interface PricingFeature {
  name: string;
  included: boolean;
}

interface PricingCardProps {
  title: string;
  description: string;
  price: string;
  period?: string;
  features: PricingFeature[];
  plan: "free" | "premium" | "enterprise";
  popular?: boolean;
  currentPlan?: boolean;
  usage?: {
    used: number;
    total: number;
  };
  onUpgrade?: () => void;
  className?: string;
}

export function PricingCard({
  title,
  description,
  price,
  period = "per month",
  features,
  plan,
  popular = false,
  currentPlan = false,
  usage,
  onUpgrade,
  className
}: PricingCardProps) {
  const planIcons = {
    free: Shield,
    premium: Crown,
    enterprise: Zap
  };

  const Icon = planIcons[plan];

  return (
    <Card className={cn(
      "relative glass-morphism hover-lift transition-all duration-300",
      popular && "border-primary border-2",
      className
    )}>
      {popular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <Badge className="premium-gradient text-primary-foreground font-bold px-6 py-2 text-sm">
            MOST POPULAR
          </Badge>
        </div>
      )}
      
      <CardHeader className="text-center pb-4">
        <div className="flex items-center justify-center mb-4">
          <div className={cn(
            "w-12 h-12 rounded-xl flex items-center justify-center",
            plan === "premium" ? "premium-gradient" : "bg-secondary"
          )}>
            <Icon className={cn(
              "w-6 h-6",
              plan === "premium" ? "text-primary-foreground" : "text-primary"
            )} />
          </div>
        </div>
        
        <h3 className={cn(
          "text-2xl font-bold mb-2",
          plan === "premium" ? "text-gradient" : "text-foreground"
        )}>
          {title}
        </h3>
        
        <p className="text-muted-foreground mb-6">{description}</p>
        
        <div className="text-center">
          <div className="text-4xl font-bold text-foreground mb-2">{price}</div>
          {period && <div className="text-muted-foreground">{period}</div>}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {usage && (
          <UsageProgress
            used={usage.used}
            total={usage.total}
            plan={plan}
            className="mb-6"
          />
        )}
        
        <div className="space-y-3">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center space-x-3">
              {feature.included ? (
                <Check className="w-5 h-5 text-primary flex-shrink-0" />
              ) : (
                <X className="w-5 h-5 text-muted-foreground flex-shrink-0" />
              )}
              <span className={cn(
                "text-sm",
                feature.included ? "text-foreground" : "text-muted-foreground"
              )}>
                {feature.name}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
      
      <CardFooter>
        {currentPlan ? (
          <Button disabled className="w-full">
            Current Plan
          </Button>
        ) : plan === "premium" ? (
          <Button 
            className="w-full premium-gradient text-primary-foreground hover:scale-105 transition-transform duration-300"
            onClick={onUpgrade}
          >
            Upgrade to Elite
          </Button>
        ) : plan === "enterprise" ? (
          <Button variant="secondary" className="w-full hover:bg-border">
            Contact Sales
          </Button>
        ) : (
          <Button variant="secondary" className="w-full hover:bg-border">
            Get Started
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
