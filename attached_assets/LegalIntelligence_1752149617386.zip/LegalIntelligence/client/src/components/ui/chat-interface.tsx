import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Send, Paperclip, Shield, CheckCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { ThinkingLogo } from "./animated-logo";

interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
  plan?: "free" | "premium";
  verified?: boolean;
}

interface ChatInterfaceProps {
  messages: Message[];
  onSendMessage: (message: string) => void;
  isLoading?: boolean;
  plan?: "free" | "premium";
  className?: string;
}

export function ChatInterface({
  messages,
  onSendMessage,
  isLoading = false,
  plan = "free",
  className
}: ChatInterfaceProps) {
  const [input, setInput] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input.trim());
      setInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <Card className={cn("flex flex-col h-full glass-premium shadow-luxury hover-lift", className)}>
      {/* Chat Header */}
      <div className="flex items-center justify-between p-4 border-b border-border gradient-border">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
          <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
        </div>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <div className="w-2 h-2 bg-primary rounded-full animate-pulse-glow"></div>
          <span className="text-gradient font-semibold">AI Active</span>
        </div>
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-muted-foreground py-12">
              <Shield className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h3 className="text-lg font-semibold mb-2">Welcome to LexAI</h3>
              <p>Ask anything about law, rights, or legal protection...</p>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex",
                message.role === "user" ? "justify-end" : "justify-start",
                "chat-message"
              )}
            >
              {message.role === "assistant" && (
                <div className="flex items-start space-x-3 max-w-2xl">
                  <div className="w-8 h-8 premium-gradient rounded-full flex items-center justify-center flex-shrink-0">
                    <Shield className="w-4 h-4 text-primary-foreground" />
                  </div>
                  <div className={cn(
                    "glass-premium rounded-2xl rounded-bl-md px-6 py-4 animate-fade-in-up",
                    message.plan === "premium" && "message-premium"
                  )}>
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-gradient-animated font-semibold text-display">LexAI</span>
                      {message.plan === "premium" && (
                        <Badge className="text-xs btn-premium text-primary-foreground animate-pulse-glow">
                          ✨ Premium
                        </Badge>
                      )}
                    </div>
                    <div className="text-foreground leading-relaxed whitespace-pre-wrap font-medium">
                      {message.content}
                    </div>
                    {message.verified && (
                      <div className="flex items-center space-x-4 mt-3 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>Legally Verified</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4 text-primary" />
                          <span>Instant Response</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {message.role === "user" && (
                <div className="flex justify-end max-w-xl animate-slide-in-right">
                  <div className="btn-premium rounded-2xl rounded-br-md px-6 py-3 hover-lift">
                    <p className="font-semibold whitespace-pre-wrap text-black">{message.content}</p>
                  </div>
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start animate-fade-in-up">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 gradient-animated rounded-full flex items-center justify-center flex-shrink-0 animate-pulse-glow">
                  <Shield className="w-4 h-4 text-primary-foreground animate-float" />
                </div>
                <div className="glass-premium rounded-2xl rounded-bl-md px-6 py-4 animate-shimmer">
                  <ThinkingLogo />
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 border-t border-border gradient-border">
        <div className="gradient-border-content">
          <form onSubmit={handleSubmit} className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask anything about law, rights, or legal protection..."
                className="pr-12 glass-morphism border-0 focus:ring-2 focus:ring-primary/50 transition-all duration-300"
                disabled={isLoading}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 hover-glow"
              >
                <Paperclip className="h-4 w-4" />
              </Button>
            </div>
            <Button
              type="submit"
              size="icon"
              disabled={!input.trim() || isLoading}
              className="btn-premium hover-lift shadow-luxury"
            >
              {isLoading ? (
                <div className="animate-spin w-4 h-4 border-2 border-black border-t-transparent rounded-full" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </form>
        </div>
      </div>
    </Card>
  );
}
