import React, { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FileText, Upload, CheckCircle, AlertCircle, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface DocumentAnalyzerProps {
  onAnalyze: (file: File) => Promise<string>;
  plan: "free" | "premium";
  className?: string;
}

interface AnalysisResult {
  summary: string;
  keyPoints: string[];
  risks: string[];
  recommendations: string[];
}

export function DocumentAnalyzer({ onAnalyze, plan, className }: DocumentAnalyzerProps) {
  const [dragActive, setDragActive] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      await analyzeFile(files[0]);
    }
  }, []);

  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      await analyzeFile(files[0]);
    }
  }, []);

  const analyzeFile = async (file: File) => {
    if (plan === "free") {
      setError("Document analysis is only available for Premium users. Upgrade to analyze legal documents.");
      return;
    }

    setAnalyzing(true);
    setError(null);
    setResult(null);
    setProgress(0);

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      const analysisText = await onAnalyze(file);
      
      clearInterval(progressInterval);
      setProgress(100);

      // Parse analysis result (in real implementation, this would be structured)
      const mockResult: AnalysisResult = {
        summary: "This document appears to be a standard contract with several important clauses that require attention.",
        keyPoints: [
          "Payment terms are clearly defined",
          "Termination clause allows for 30-day notice",
          "Intellectual property rights are assigned to the company"
        ],
        risks: [
          "Non-compete clause may be overly restrictive",
          "Liability limitations heavily favor the other party",
          "Arbitration clause requires specific jurisdiction"
        ],
        recommendations: [
          "Review non-compete terms with legal counsel",
          "Negotiate more balanced liability terms",
          "Consider alternative dispute resolution options"
        ]
      };

      setTimeout(() => {
        setResult(mockResult);
        setAnalyzing(false);
      }, 1000);

    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to analyze document");
      setAnalyzing(false);
      setProgress(0);
    }
  };

  return (
    <div className={cn("space-y-6", className)}>
      {/* Upload Area */}
      <Card className="glass-morphism">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-primary" />
            <span>Document Analysis</span>
            {plan === "premium" && (
              <Badge className="premium-gradient text-primary-foreground text-xs">
                Premium
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div
            className={cn(
              "border-2 border-dashed rounded-lg p-8 text-center transition-colors duration-200",
              dragActive ? "border-primary bg-primary/10" : "border-border",
              plan === "free" ? "opacity-50" : ""
            )}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Upload Legal Document</h3>
            <p className="text-muted-foreground mb-4">
              Drag and drop your PDF, or click to browse
            </p>
            
            {plan === "free" ? (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Document analysis requires Premium subscription
                </p>
                <Button className="premium-gradient text-primary-foreground">
                  Upgrade to Premium
                </Button>
              </div>
            ) : (
              <div>
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload">
                  <Button asChild>
                    <span>Choose File</span>
                  </Button>
                </label>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Analysis Progress */}
      {analyzing && (
        <Card className="glass-morphism animate-scale-in">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 premium-gradient rounded-full flex items-center justify-center animate-pulse">
                <FileText className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold mb-2">Analyzing Document...</h3>
                <Progress value={progress} className="h-2" />
                <p className="text-sm text-muted-foreground mt-2">
                  AI is reviewing your document for legal insights
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error State */}
      {error && (
        <Card className="glass-morphism border-destructive/50 animate-scale-in">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <AlertCircle className="w-6 h-6 text-destructive flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold text-destructive mb-2">Analysis Failed</h3>
                <p className="text-muted-foreground">{error}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setError(null)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Analysis Results */}
      {result && (
        <Card className="glass-morphism animate-scale-in">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span>Analysis Complete</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Summary */}
            <div>
              <h3 className="font-semibold mb-2 text-primary">Summary</h3>
              <p className="text-foreground">{result.summary}</p>
            </div>

            {/* Key Points */}
            <div>
              <h3 className="font-semibold mb-3 text-primary">Key Points</h3>
              <ul className="space-y-2">
                {result.keyPoints.map((point, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Risks */}
            <div>
              <h3 className="font-semibold mb-3 text-yellow-500">Potential Risks</h3>
              <ul className="space-y-2">
                {result.risks.map((risk, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-yellow-500 flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{risk}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Recommendations */}
            <div>
              <h3 className="font-semibold mb-3 text-primary">Recommendations</h3>
              <ul className="space-y-2">
                {result.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
