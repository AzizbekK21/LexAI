import React from "react";
import { Button } from "@/components/ui/button";
import { Twitter, Linkedin, Github, Apple, Smartphone } from "lucide-react";
import { AnimatedLogo } from "@/components/ui/animated-logo";
import { cn } from "@/lib/utils";

interface FooterProps {
  className?: string;
}

export function Footer({ className = "" }: FooterProps) {
  const footerLinks = {
    product: [
      { label: "Features", href: "#features" },
      { label: "Pricing", href: "#pricing" },
      { label: "API", href: "#" },
      { label: "Security", href: "#" },
    ],
    company: [
      { label: "About", href: "#" },
      { label: "Blog", href: "#" },
      { label: "Careers", href: "#" },
      { label: "Contact", href: "#" },
    ],
  };

  return (
    <footer className={cn("bg-secondary border-t border-border", className)}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="md:col-span-2">
            <AnimatedLogo size="md" className="mb-4" />
            <p className="text-muted-foreground mb-6 max-w-md">
              Revolutionary AI legal assistant providing luxury intelligence and protection against government intimidation and legal uncertainty.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="hover:bg-primary hover:text-primary-foreground">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:bg-primary hover:text-primary-foreground">
                <Linkedin className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:bg-primary hover:text-primary-foreground">
                <Github className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          {/* Product Links */}
          <div>
            <h3 className="text-foreground font-semibold mb-4">Product</h3>
            <ul className="space-y-2 text-muted-foreground">
              {footerLinks.product.map((link) => (
                <li key={link.label}>
                  <a 
                    href={link.href} 
                    className="hover:text-primary transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Company Links */}
          <div>
            <h3 className="text-foreground font-semibold mb-4">Company</h3>
            <ul className="space-y-2 text-muted-foreground">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a 
                    href={link.href} 
                    className="hover:text-primary transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Mobile App CTA */}
        <div className="mt-8 p-6 glass-morphism rounded-2xl text-center">
          <p className="text-muted-foreground mb-4">
            This web version includes limited ads. Want a fully ad-free experience?
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button variant="secondary" className="hover:bg-border">
              <Apple className="w-5 h-5 mr-2" />
              Download on App Store
            </Button>
            <Button variant="secondary" className="hover:bg-border">
              <Smartphone className="w-5 h-5 mr-2" />
              Get it on Google Play
            </Button>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 flex flex-col md:flex-row items-center justify-between">
          <p className="text-muted-foreground text-sm">
            © 2024 LexAI. All rights reserved. | Intelligence + Power + Respect for People
          </p>
          <div className="flex items-center space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-200 text-sm">Privacy Policy</a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-200 text-sm">Terms of Service</a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-200 text-sm">Legal</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
