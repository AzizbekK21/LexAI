export const API_ENDPOINTS = {
  CHAT: "/api/chat",
  USAGE: "/api/usage",
  DASHBOARD: "/api/dashboard",
  CONVERSATIONS: "/api/conversations",
  ANALYZE_DOCUMENT: "/api/analyze-document",
  SUBSCRIPTION: "/api/subscription",
} as const;

export const PLANS = {
  FREE: {
    name: "Free Shield",
    price: 0,
    maxQuestions: 50,
    model: "mistral-small",
    features: ["Basic legal guidance", "Chat history", "50 AI questions/month"],
  },
  PREMIUM: {
    name: "Elite Protection",
    price: 50,
    maxQuestions: 150,
    model: "gpt-4o",
    features: [
      "Advanced legal analysis",
      "PDF document analysis", 
      "Contract review",
      "No advertisements",
      "Priority support",
      "150 AI questions/month"
    ],
  },
  ENTERPRISE: {
    name: "Enterprise",
    price: "custom",
    maxQuestions: Infinity,
    model: "custom",
    features: [
      "Unlimited questions",
      "Custom AI models",
      "Bulk document processing",
      "API access",
      "White-label options",
      "Dedicated support"
    ],
  },
} as const;

export const AI_MODELS = {
  FREE: "mistralai/mistral-small-24b-instruct-2501:free",
  PREMIUM: "gpt-4o",
} as const;

export const ANIMATIONS = {
  DURATION: {
    SHORT: 200,
    MEDIUM: 300,
    LONG: 500,
  },
  EASING: {
    EASE_OUT: "cubic-bezier(0.4, 0, 0.2, 1)",
    EASE_IN_OUT: "cubic-bezier(0.4, 0, 0.6, 1)",
    BOUNCE: "cubic-bezier(0.68, -0.55, 0.265, 1.55)",
  },
} as const;

export const COLORS = {
  GOLD: "#FFD700",
  GOLD_ORANGE: "#FFA500", 
  DARK_GOLD: "#B8860B",
  DEEP_BLACK: "#0e0e0e",
  DARK_GRAY: "#1a1a1a",
  MEDIUM_GRAY: "#2a2a2a",
  LIGHT_GRAY: "#e2e2e2",
} as const;
