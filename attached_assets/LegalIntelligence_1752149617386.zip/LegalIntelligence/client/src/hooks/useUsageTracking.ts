import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface UsageData {
  used: number;
  total: number;
  plan: "free" | "premium";
  resetDate: Date;
}

export function useUsageTracking() {
  const queryClient = useQueryClient();

  const { data: usage, isLoading } = useQuery<UsageData>({
    queryKey: ["/api/usage"],
    queryFn: async () => {
      const response = await fetch("/api/usage", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch usage");
      return response.json();
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const incrementUsageMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/usage/increment", {
        method: "POST",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to increment usage");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/usage"] });
    },
  });

  const canMakeRequest = () => {
    if (!usage) return false;
    return usage.used < usage.total;
  };

  const getRemainingRequests = () => {
    if (!usage) return 0;
    return Math.max(0, usage.total - usage.used);
  };

  const getUsagePercentage = () => {
    if (!usage) return 0;
    return (usage.used / usage.total) * 100;
  };

  const isNearLimit = () => {
    return getUsagePercentage() >= 80;
  };

  const isAtLimit = () => {
    return getUsagePercentage() >= 100;
  };

  const getDaysUntilReset = () => {
    if (!usage) return 0;
    const now = new Date();
    const resetDate = new Date(usage.resetDate);
    const timeDiff = resetDate.getTime() - now.getTime();
    return Math.ceil(timeDiff / (1000 * 3600 * 24));
  };

  return {
    usage,
    isLoading,
    canMakeRequest,
    getRemainingRequests,
    getUsagePercentage,
    isNearLimit,
    isAtLimit,
    getDaysUntilReset,
    incrementUsage: incrementUsageMutation.mutate,
    isIncrementing: incrementUsageMutation.isPending,
  };
}
