# LexAI - Elite Legal Intelligence

## Overview

LexAI is a revolutionary AI legal assistant application providing luxury intelligence and protection against government intimidation. The application features a modern React frontend with Express.js backend, utilizing PostgreSQL for data persistence and multiple AI models for legal guidance.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **AI Integration**: Multiple providers (OpenAI GPT-4o, OpenRouter Mistral)
- **Session Management**: PostgreSQL-based session storage

### Database Schema
- **Users**: Plan management, usage tracking, subscription data
- **Conversations**: Chat history organization
- **Messages**: Individual chat messages with AI metadata
- **Documents**: File analysis storage and results
- **Subscriptions**: Payment and plan status tracking

## Key Components

### AI Service Layer
- **Multi-Provider Support**: OpenAI for premium users, OpenRouter for free tier
- **Plan-Based Routing**: Different models based on subscription level
- **Legal Specialization**: Custom prompts optimized for legal guidance
- **Usage Tracking**: Per-plan request limits and monitoring

### Authentication & Authorization
- **Demo Mode**: Currently uses mock session with demo user
- **Plan-Based Features**: Free (50 questions), Premium (150 questions), Enterprise (unlimited)
- **Usage Monitoring**: Real-time tracking with automatic reset cycles

### Document Analysis
- **Premium Feature**: PDF document analysis for legal review
- **AI-Powered**: Contract review, risk assessment, and recommendations
- **File Upload**: Drag-and-drop interface with progress tracking

### Chat Interface
- **Real-time Messaging**: Instant AI responses with typing indicators
- **Message History**: Persistent conversation storage
- **Verification System**: Premium responses marked as verified
- **Plan Indicators**: Visual distinction between free and premium responses

## Data Flow

1. **User Request**: Frontend sends message via REST API
2. **Usage Check**: Backend validates user's remaining quota
3. **AI Processing**: Route to appropriate AI service based on plan
4. **Response Storage**: Save both user message and AI response
5. **Usage Update**: Increment user's usage counter
6. **Real-time Update**: Return response to frontend with metadata

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4o for premium legal analysis
- **OpenRouter API**: Mistral Small for free tier users
- **Neon Database**: Serverless PostgreSQL hosting

### Frontend Libraries
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling framework
- **TanStack Query**: Server state synchronization
- **React Hook Form**: Form validation and management

### Development Tools
- **Vite**: Fast development server and build tool
- **Drizzle Kit**: Database migrations and schema management
- **TypeScript**: Type safety across the stack

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: esbuild compiles TypeScript server to `dist/index.js`
- **Database**: Drizzle migrations handle schema updates

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **OPENAI_API_KEY**: Premium AI service access
- **OPENROUTER_API_KEY**: Free tier AI service access
- **NODE_ENV**: Environment-specific configurations

### Production Considerations
- **Session Security**: PostgreSQL-based session storage
- **Rate Limiting**: Built-in usage tracking per user plan
- **Error Handling**: Comprehensive error boundaries and logging
- **Performance**: Optimized queries and caching strategies

### Scaling Architecture
- **Stateless Backend**: Horizontal scaling capability
- **Database Pooling**: Connection optimization for concurrent users
- **CDN Ready**: Static assets optimized for content delivery
- **WebSocket Support**: Framework prepared for real-time features